let colorBtn, sizeSlider, shapeSelect;
let shapeColor;
let brightnessSlider, rotateSlider;

function setup() {
  createCanvas(640, 800);
  noStroke();
  textFont("Georgia");

  // starting color
  shapeColor = color(128);
  // shapeColor = color(random(255), random(255), random(255));

  // Button: change color
//   colorBtn = createButton("Change Color");
//   colorBtn.position(16, 16);
//   colorBtn.mousePressed(randomShapeColor);
  
//   function randomShapeColor() {
//     shapeColor = color(random(255), random(255), random(255));
//   }

  // Slider: controls colors
  createP("Brightness").position(0, 700).style("margin", "-16px 0 0 280px");
  brightnessSlider = createSlider(20, 220, 100, 1);
  brightnessSlider.position(20, 700);
  brightnessSlider.style('width', '600px');    
  brightnessSlider.style('margin', '10px auto'); 
  brightnessSlider.style('accent-color', '#E91E63');

  
  // Slider: controls size
  createP("Size").position(0, 650).style("margin", "-16px 0 0 300px");
  sizeSlider = createSlider(20, 220, 100, 1);
  sizeSlider.position(20, 650);
  sizeSlider.style('width', '600px');    
  sizeSlider.style('margin', '10px auto'); 
  sizeSlider.style('accent-color', '#3F51B5');
  
  // Slider: controls rotate
  createP("Rotation").position(0, 600).style("margin", "-16px 0 0 280px");
  rotateSlider = createSlider(0, 360, 0); // 0~360度
  rotateSlider.position(20, 600);
  rotateSlider.style('width', '600px');
  rotateSlider.style('accent-color', '#4CAF50');


  // Dropdown: choose shape
  createP("Shape").position(0, 100).style("margin", "8px 0 0 16px");
  shapeSelect = createSelect();
  shapeSelect.position(16, 130);
  shapeSelect.option("ellipse");
  shapeSelect.option("rect");
  shapeSelect.option("triangle");
}

function draw() {
  background(240);

  push();
  translate(width * 0.5, height * 0.5);
  let s = sizeSlider.value();

  let bright = brightnessSlider.value();
  fill(bright);
  // fill(shapeColor);
  
  // draw chosen shape
  let choice = shapeSelect.value();
  
  let angle = radians(rotateSlider.value());
  
  if (choice === "ellipse") {
    for(let i = 1; i <=5; i++){
      let x = -3*width/5 + width/5 * i;
      let y = 0;
      
      push();
      translate(x, y);
      rotate(angle);
      ellipse(0, 0, 20, s * 2);
      pop();
    }
  } else if (choice === "rect") {
    rectMode(CENTER);
    
    for(let i = 1; i <=5; i++){
      let x = -3*width/5 + width/5 * i;
      let y = 0;
      
      push();
      translate(x, y);
      rotate(angle);
      rect(0, 0, s/2, s * 2);
      pop();
    }    
  } else if (choice === "triangle") {
    for(let i = 1; i <=5; i++){
    let x = -3*width/5 + width/5 * i;
    push();
    translate(x, 0);
    rotate(angle);
    triangle(0, -s*0.5,   -s*0.5, s*0.4,   s*0.5, s*0.4);
    pop();
  }
  }
  pop();
}
