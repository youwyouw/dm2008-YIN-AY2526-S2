// DM2008 – Activity 4a
// Bake a Cookie (30 min)

let cookie;
let flavorOptions = ["chocolate", "vanilla", "matcha"];
let x = 300, y = 300;

function setup() {
  createCanvas(600, 600);
  noStroke();

  // Step 3: make one cookie object
  cookie = new Cookie(flavorOptions[0], 150, x, y);
}

function draw() {
  background(230);

  // Step 4: call the cookie’s show() method
  cookie.show();
}

// Step 1: define the Cookie class
class Cookie {
  constructor(flavor, sz, x, y) {
    // set up required properties
    this.flavor = flavor;
    this.sz = sz;
    this.x = x;
    this.y = y;
  }

  // Step 2: display the cookie
  show() {
    switch (this.flavor) {
      case "chocolate":
        fill(196, 146, 96);
        break;
      case "vanilla":
        fill(245, 222, 179);
        break;
      case "matcha":
        fill(120, 170, 120);
        break;
      default:
        fill(220, 180, 120);
    }
    ellipse(this.x, this.y, this.sz);
    
    	
    // a few "chips" placed relative to size
    const s = this.sz * 0.1;
    fill(60);
    ellipse(this.x - this.sz*0.22, this.y - this.sz*0.15, s);
    ellipse(this.x + this.sz*0.18, this.y - this.sz*0.10, s);
    ellipse(this.x - this.sz*0.05, this.y + this.sz*0.28, s);
    ellipse(this.x + this.sz*0.20, this.y + this.sz*0.18, s);
  }

  // Steps 5 & 6: Implement additional methods here
  randomizeFlavor(){
    let randomIndex = floor(random(flavorOptions.length));
    this.flavor = flavorOptions[randomIndex];
  }
  
  move(dx, dy) {
    this.x += dx;
    this.y += dy;
  }
}

// Step 5: add movement (keyboard arrows)
function keyPressed() {
    const step = 5;
    if (key == 'A' || key == 'a') {
      cookie.move(-step, 0);
    }
    if (key == 'D' || key == 'd') {
      cookie.move(step, 0);
    }
    if (key == 'W' || key == 'w') {
      cookie.move(0, -step);
    }
    if (key == 'S' || key == 's') {
      cookie.move(0, step);
    }
}

// Step 6: add flavor randomizer (mouse click)
function mousePressed() {
    cookie.randomizeFlavor();
}
