// DM2008 — Activity 3b
// (One Function Wonder, 20 min)

let angle = 0;

function setup() {
  createCanvas(800, 800);
  rectMode(CENTER);
}

function draw() {
  background(220, 40);

  // TODO 1:
  // Define a function that draws something (a shape or group of shapes).
  // It should take at least one parameter (e.g., position, size, or color).
  
  // TODO 2:
  // Call your function multiple times with different parameter values.
  // myShape(100, 200, 50);
  // myShape(300, 200, 80);

  
  translate(width/2, height/2);
  rotate(angle);
  
  angle += 0.01;
    
  for(let i=0; i < 5; i++){
    shape(0, i*50, 30 + i * 10, color(255, 180, 80+i*50));
    shape(i*50, height/2 - 120, 30 + i * 10, color(200, 160+i*50, 100));
//    shape(0 + i*40, height/2 + i*40, 30 + i * 10, color(0));
  }
  

  // TODO 3:
  // (Challenge) Call your function inside a for loop
  // to create a repeating pattern or variation.
}

// Example starter function:
// function myShape(x, y, s) {
//   ellipse(x, y, s, s);
// }

function shape(x, y, r, c){
  noStroke();
  fill(c);
  ellipse(x, y, r);
}