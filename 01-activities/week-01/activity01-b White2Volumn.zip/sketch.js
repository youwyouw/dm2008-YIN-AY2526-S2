// DM2008
// Activity 1b (Ryoji Ikeda)

let x;
let y;
let w;

function setup() {
  createCanvas(800, 800);
  background(0);
  noStroke();
  fill(255);
}

function draw() {
  background(200, 20);
  
  x = random(width);
  y = random(height);
  w = random(1, 20);
  rect(width/2, y, w*40, w);

  rect(width/2, y, -w*40, -w/3);
  
}

function keyPressed() {
  saveCanvas("activity1b-image", "jpg");
}