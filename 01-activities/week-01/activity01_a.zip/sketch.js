// DDM2008
// Activity 1a

// Run the sketch, then click on the preview to enable keyboard
// Use the 'Option' ('Alt' on Windows) key to view or hide the grid
// Use the 'Shift' key to change overlays between black & white
// Write the code for your creature in the space provided

function setup() {
  createCanvas(600, 600);
}

function draw() {
  background(255,230,240);
  
  // YOUR CODE HERE
  fill(0);
  rect(170, 250, 230, 60);
  noStroke();
  
  rect(230, 310, 50, 40);
  fill(0);
  noStroke();
  rect(320, 310, 50, 40);
  fill(0);
  noStroke();
  
  ellipse(400, 240, 30, 40);
  fill(0);
  noStroke();
  
  fill(20,255,20);  
  triangle(230,290,170,290,170,300);  
  noStroke();
  
  fill(0);  
  triangle(270,250,230,250,230,190);
  triangle(340,250,300,250,300,190);
 
  // YOUR CODE HERE
//  function helperGrid() {// grind
//  stroke(200);
//  strokeWeight(0.5);
//  for (let x = 0; x < width; x += 20) {
//     line(x, 0, x, height);
//   }
//   for (let y = 0; y < height; y += 20) {
//     line(0, y, width, y);
//   }
// }
  
//  helperGrid(); // do not edit or remove this line
}


function keyPressed() {
  saveCanvas("activity1a-image", "jpg");
}