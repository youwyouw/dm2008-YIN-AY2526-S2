// DM2008 — Activity 2a [Guided]
// Mode Switch (20 min)
//
// Keys 1, 2, 3 switch between modes — each one changes the background color.
// Try extending each mode to also change the fill, size, or speed of the ellipse.
// Keep it simple: one clear change per mode that's easy to see on screen.
//
// Stretch: add a 4th mode, or make the ellipse change shape between modes.

let x = 0;       // ellipse x-position
let size = 150;   // ellipse size
let bgColor;     // background color, changed by key presses

let mode = 0;

function setup() {
  createCanvas(400, 400);
  bgColor = color(220);
}

function draw() {
  background(bgColor, 150);

  noStroke();
  
  // Draw the ellipse at its current position
  if (mouseIsPressed) {
    fill(255, 0, 0); // red on click
    ellipse(x, height / 2, size+15);
  } else {
    fill(0);
    ellipse(x, height / 2, size);
  }

  // Move the ellipse
  x = width / 2 + sin(frameCount * 0.03) * 150;
  
  // Wrap around when it exits the right edge
  if (x > width + size / 2) {
    x = 0;
  }

  // --- Your if/else goes here ---
  // Try swapping this out for your own rule.  
  if (mode === 1) {
    for (let i = 0; i < 16; i++) {
      let y = random(height);
      let h = random(10, 30);
      fill(255, 60); // 半透明白，刚好不深不浅
      noStroke();
      rect(0, y, width, h);
    }
    fill(255, 0, 0); // red on click
    ellipse(x, height / 2, size+15);
  }
  else if (mode === 2){
    
  }
  
}

// Keys 1, 2, 3 change the background color — this is your mode switch
function keyPressed() {
  switch (key) {
    case "1":
      bgColor = color(0);
      mode = 1;
      break; // red
    case "2":
      bgColor = color(100, 200, 100);
      break; // green
    case "3":
      bgColor = color(100, 100, 200);
      break; // blue
    default:
      bgColor = color(220); // grey
      mode = 0;
  }
}
