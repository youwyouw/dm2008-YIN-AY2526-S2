// DM2008 — Activity 2b
// (Pattern Making, 40 min)

function setup() {
  createCanvas(800, 600);
}

function draw() {
  background(210);

  for (let i = 0; i < 100; i++){
    for(let j =0; j < 9; j++){
      if (j % 2 == 0){
        stroke(200);
        strokeWeight(0.8);
      }      
      else{
        stroke(255); 
        strokeWeight(2);
      }

      line(j*100, height/2,  mouseX, mouseY + 300 * sin(i*2));

    }
    
  }
  
  
}