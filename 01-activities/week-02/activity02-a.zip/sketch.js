let x;
let y;
let w;
let r, g, b;
let R;

function setup() {
  createCanvas(1000, 500);
  r = 240;
  g = 240;
  b = 240;
  R = height/2;
}

function draw() {

  background(r, g, b);
  
  if(mouseIsPressed){
    noStroke();
    fill(255);
    x = random(width);
    y = random(height);
    w = random(5, 50);
    rect(width/2, y, w*40, w);

    rect(width/2, y, -w*40, -w/3);
  }
  
  noStroke();
  ellipse(width/2, height/2, R);
  
  if(keyIsPressed){
    switch (key){
      case 'r':
        r = r - sin(random(0, 2*PI))*20;
        break;        
      case 'g':
        g -= sin(random(0, 2*PI))*20;
        break;      
      case 'b':
        b -= sin(random(0, 2*PI))*20;
        break;      
      case ' ':
        R += sin(random(0, 2*PI))*30;
    }
  }
  

}